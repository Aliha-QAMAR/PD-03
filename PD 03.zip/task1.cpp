#include <iostream>
using namespace std;
int main(){

int n;
float degrees;
float sum;
cout<<" Enter the number of sides of polygon:";
cin>> n;
sum = (n-2) * 180 ;
cout<< " The sum of internal angles of a 40-sided polygon is : " << sum << " degress " ;
}





