#include <iostream>
using namespace std;
main(){
int age;
int NumberOfMoves;
int average;
int totalHouses; 
cout<<" Enter the person's age : ";
cin>> age;
cout<<" Enter the number of times they've moved : ";
cin>>NumberOfMoves;
totalHouses = ( NumberOfMoves + 1 );
average = (age / totalHouses );
cout<<" Average number of years lived in the same house : " << average;





}