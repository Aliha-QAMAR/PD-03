#include <iostream>
using namespace std;
main(){

int squareMetersToBePainted;
int width;
int height;
int numberOfWalls;
int area;

 
cout<<" Number of square meters you can paint : ";
cin>>squareMetersToBePainted;
cout<<" Width of single wall (in meters) : ";
cin>>width;
cout<<" Height  of single wall ( in meters) : ";
cin>> height;
area = ( width * height );
numberOfWalls = (squareMetersToBePainted / area ) ;
cout<< " Number of wall you can paint :" << numberOfWalls ; 














}