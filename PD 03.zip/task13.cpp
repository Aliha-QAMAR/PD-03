#include <iostream>
using namespace std;
main(){
int num1;
int num2;
cout<<"Enter the first number : ";
cin>>num1;
cout<<"Enter the second number : ";
cin>>num1;
cout<<"Enter the third number : ";
cin>>num1;
cout<<"Enter the fourth number : ";
cin>>num1;
cout<<"Enter the fifth number : ";
cin>>num1;

num2 = (num1 + num1 + num1 + num1 + num1);
cout<< "The sum of 5 numbers is : " << num2 ;















}