#include <iostream>
using namespace std;
int main(){

int minutes;
int frames;
int totalFrames;

cout<<" Number of  minutes :";
cin>> minutes;
cout<<" Frames per second :";
cin>> frames;
totalFrames = (minutes * 60) * frames;
cout<< "Total Number of Frames = " << totalFrames;

}





