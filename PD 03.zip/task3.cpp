#include <iostream>
using namespace std;
int main(){
int InitialVelocity;
int Acceleration;
int Time;
int FinalVelocity;
cout<<" Enter InitialVelocity (m/s):";
cin>>InitialVelocity;
cout<<" Enter Acceleration (m/s^2):";
cin>> Acceleration;
cout<<" Time (s):";
cin>> Time;

FinalVelocity = (Acceleration * Time ) + InitialVelocity;
cout<< "FinalVelocity (m/s) = " << FinalVelocity;



}





