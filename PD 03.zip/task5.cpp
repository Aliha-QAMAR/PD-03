#include <iostream>
using namespace std;
int main(){
string name ;
int weight ;
int theTargetWeightLoss ;
int days;


cout<<" Enter Name of the Person :";
cin>> name;
cout<<" Enter the target weight loss in kilograms  :";
cin>> weight ;

days = ( weight * 15 ) ;
cout<< "Amir will need " << days << " days to lose " << weight << " kg of weight by following the doctor's suggestions";





}





