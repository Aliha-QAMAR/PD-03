#include <iostream>
using namespace std;
int main(){
int size;
int cost;
int area;
int costPerPound;
int costPerFoot;
cout<<"Enter the size of the fertilizer bag in pounds: ";
cin>> size;
cout<<"Enter the cost of bag: $";
cin>> cost;
cout<<"Enter the area in square feet that can be covered by the bag: ";
cin>> area;
costPerPound = cost/size;
costPerFoot = cost/area;
cout<<"Cost of fertilizer per pound: $" << costPerPound<<endl;
cout<<"Cost of fertilizing per square foot: $" << costPerFoot<<endl;
}





