#include <iostream>
using namespace std;
#include<iostream>
using namespace std;
int main(){

string movieName;
int childTicketPrice;
int adultTicketPrice;
int childTicketSold;
int adultTicketSold;
float percentageOfTheAmountToBeDonated;
int remaminingAmountAfterDonation;
int totalPrice;																																																		
int donationToCharity;
cout<<"Enter the movieName:";
cin>> movieName;
cout<<"Enter the child ticket price:" << "$";
cin>> childTicketPrice;
cout<<"Enter the adult ticket price:" << "$";
cin>> adultTicketPrice ;
cout<<"Enter the child ticket sold:" <<"$";
cin>>  childTicketSold ;
cout<<"Enter the adult ticket sold:" <<"$";
cin>> adultTicketSold ;
cout<< "Enter percentage Of The Amount To Be Donated to charity:";
cin>> percentageOfTheAmountToBeDonated;
totalPrice = (childTicketPrice*childTicketSold) + (adultTicketPrice*adultTicketSold) ;
donationToCharity= (totalPrice * 10)/100 ;
remaminingAmountAfterDonation = totalPrice - donationToCharity ;
cout<<"Total amount generated from ticket sales :" << "$"<< totalPrice << endl ;
cout<<"Donation to charity (10%) = "<<"$"<< donationToCharity <<  endl ;
cout<<"Remamining Amount After Donation = " <<"$" << remaminingAmountAfterDonation <<  endl ;
}








