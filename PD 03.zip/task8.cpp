#include <iostream>
using namespace std;
main(){

float vegetablePricePerKilogram;
float FruitPricePerKilogram;
int totalKilogramsOfVegetables;
int totalKilogramsOfFruits;
int earningOfVegetables;
int earningOfFruits;
float totalEarnings;
float sumOfEarnings;

cout<<" Enter vegetable price per kilogram ( in coins) : ";
cin>>vegetablePricePerKilogram;
cout<<" Enter fruit price per kilogram ( in coins ) : ";
cin>>FruitPricePerKilogram ;
cout<<" Enter total kilograms of vegetables : ";
cin>>totalKilogramsOfVegetables;
cout<<" Enter total kilograms of fruits : ";
cin>>totalKilogramsOfFruits;

earningOfVegetables = (vegetablePricePerKilogram * totalKilogramsOfVegetables) ;
earningOfFruits = (FruitPricePerKilogram *  totalKilogramsOfFruits );
sumOfEarnings = ( earningOfVegetables + earningOfFruits );
totalEarnings = (sumOfEarnings / 1.94);
cout<< " Total earnings in Rupees (Rps) : " << totalEarnings ;


}
